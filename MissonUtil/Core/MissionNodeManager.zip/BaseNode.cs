using UnityEngine;
namespace demonviglu.MissonSystem
{
    public class BaseNode : ScriptableObject
    {
        public string GUID;
    }
}

